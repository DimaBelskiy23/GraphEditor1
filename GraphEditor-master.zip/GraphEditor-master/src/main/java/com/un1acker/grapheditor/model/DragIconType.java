package com.un1acker.grapheditor.model;

/**
 * Three types of hypergraph nodes
 * @author un1acker
 * */

public enum DragIconType {
    node,
    joint,
    global,
}